const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electron', {
  startBluetooth: () => ipcRenderer.send('startBluetooth'),
  onBluetoothData: (callback) => ipcRenderer.on('bluetoothData', callback),
});
